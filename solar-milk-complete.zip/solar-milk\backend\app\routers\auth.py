from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.database import get_db
from app.services.auth_service import authenticate_farmer, create_access_token, get_current_farmer
from app.schemas.auth import Token, FarmerProfile

router = APIRouter(prefix="/auth", tags=["auth"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

@router.post("/login", response_model=Token)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    farmer = authenticate_farmer(db, form.username, form.password)
    if not farmer:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = create_access_token({"sub": farmer.id, "mobile": farmer.mobile})
    return Token(access_token=token, token_type="bearer", farmer_id=farmer.id, farmer_name=farmer.name, mobile=farmer.mobile)

@router.get("/me", response_model=FarmerProfile)
def me(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    farmer = get_current_farmer(db, token)
    if not farmer:
        raise HTTPException(status_code=401, detail="Invalid token")
    return farmer

