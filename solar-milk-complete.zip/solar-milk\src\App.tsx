import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import Sidebar from './components/Sidebar'
import { TelemetrySimulatorBar } from './components/TelemetrySimulatorBar'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import MyMilkCan from './pages/MyMilkCan'
import Temperature from './pages/Temperature'
import BatterySolar from './pages/BatterySolar'
import BluetoothStatus from './pages/BluetoothStatus'
import Alerts from './pages/Alerts'
import Settings from './pages/Settings'

function AppShell() {
  const { isAuthenticated } = useApp()
  if (!isAuthenticated) return <Login />
  return (
    <div className="flex h-screen bg-green-50 overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TelemetrySimulatorBar />
        <main className="flex-1 overflow-y-auto p-6">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/my-can" element={<MyMilkCan />} />
            <Route path="/temperature" element={<Temperature />} />
            <Route path="/battery-solar" element={<BatterySolar />} />
            <Route path="/bluetooth" element={<BluetoothStatus />} />
            <Route path="/alerts" element={<Alerts />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AppShell />
      </AppProvider>
    </BrowserRouter>
  )
}
