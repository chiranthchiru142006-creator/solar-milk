from sqlalchemy import Column, Integer, String, DateTime
from datetime import datetime, timezone
from app.database import Base

class SMSLog(Base):
    __tablename__ = "sms_logs"
    id            = Column(Integer, primary_key=True, index=True, autoincrement=True)
    farmer_id     = Column(String, nullable=False, index=True)
    mobile        = Column(String, nullable=False)
    message       = Column(String, nullable=False)
    status        = Column(String, default="pending")
    condition_key = Column(String, nullable=True)
    sent_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))

