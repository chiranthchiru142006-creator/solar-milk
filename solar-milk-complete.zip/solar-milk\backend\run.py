if __name__ == "__main__":
    import uvicorn
    from app.database import engine, Base
    Base.metadata.create_all(bind=engine)
    from sqlalchemy.orm import Session
    db = Session(engine)
    from app.seed import seed_database
    seed_database(db)
    db.close()
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)

