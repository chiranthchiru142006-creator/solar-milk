from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class TelemetryIngest(BaseModel):
    can_id: str
    temperature_c: float
    battery_voltage: float
    solar_voltage: float
    milk_quantity_litres: float = 0.0
    bluetooth_connected: bool = True
    battery_temperature_c: Optional[float] = 30.0
    signal_strength_dbm: Optional[int] = -60

class TelemetryOut(BaseModel):
    id: int
    can_id: str
    timestamp: datetime
    temperature_c: float
    battery_voltage: float
    solar_voltage: float
    milk_quantity_litres: float
    bluetooth_connected: bool
    battery_temperature_c: float
    signal_strength_dbm: int

    class Config:
        from_attributes = True
