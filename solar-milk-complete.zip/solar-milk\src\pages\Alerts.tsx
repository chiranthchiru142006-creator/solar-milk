import React, { useEffect, useState } from 'react'
import { Bell, AlertTriangle, CheckCircle2, Info, MessageSquare } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { getAlerts } from '../api/sensorService'

interface Alert {
  id: number
  alert_type: string
  message: string
  severity: 'info' | 'warning' | 'critical'
  is_resolved: boolean
  created_at: string
  sms_sent: boolean
}

export default function Alerts() {
  const { token, farmerId, currentCan } = useApp()
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [filter, setFilter] = useState<'all' | 'warning' | 'info'>('all')
  const [loading, setLoading] = useState(true)

  const canId = farmerId === 'f_chiranth' ? 'can_chiranth_1' : 'can_anisha_1'

  useEffect(() => {
    if (!token) return
    setLoading(true)
    getAlerts(token, canId).then(setAlerts).catch(() => setAlerts([])).finally(() => setLoading(false))
  }, [token, canId])

  const filtered = filter === 'all' ? alerts : alerts.filter(a => a.severity === filter)

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bell className="text-red-500" size={28} />
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Alerts & SMS Notifications</h1>
            <p className="text-gray-500 text-sm">Notification records for {currentCan?.farmer_name} ({currentCan?.can_name})</p>
          </div>
        </div>
        <div className="flex gap-2">
          {(['all', 'warning', 'info'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-lg text-xs font-medium capitalize ${filter === f ? 'bg-green-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 flex items-start gap-3">
        <MessageSquare size={18} className="text-orange-500 mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-semibold text-orange-800">SMS Integration</p>
          <p className="text-xs text-orange-600 mt-1">
            Set <code className="bg-orange-100 px-1 rounded">SMS_MODE=fast2sms</code> and{' '}
            <code className="bg-orange-100 px-1 rounded">FAST2SMS_API_KEY=your_key</code> in{' '}
            <code className="bg-orange-100 px-1 rounded">backend/.env</code> to enable real SMS.
            Sign up free at <strong>fast2sms.com</strong>.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-gray-400">Loading alerts…</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <CheckCircle2 size={40} className="text-green-400 mx-auto mb-3" />
          <p className="text-gray-500">No alerts — your milk can is running smoothly!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(alert => (
            <div key={alert.id} className={`bg-white rounded-xl p-4 shadow-sm border ${
              alert.severity === 'critical' ? 'border-red-200' : alert.severity === 'warning' ? 'border-yellow-200' : 'border-blue-100'
            }`}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2">
                  {alert.severity === 'critical' ? <AlertTriangle size={16} className="text-red-500" />
                   : alert.severity === 'warning' ? <AlertTriangle size={16} className="text-yellow-500" />
                   : <Info size={16} className="text-blue-500" />}
                  <div>
                    <p className="text-sm font-medium text-gray-900">{alert.message}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{new Date(alert.created_at).toLocaleString('en-IN')}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  {alert.is_resolved
                    ? <span className="text-xs text-green-600 bg-green-50 px-2 py-0.5 rounded-full">Resolved</span>
                    : <span className="text-xs text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full">Active</span>}
                  {alert.sms_sent && <span className="text-xs text-blue-600 flex items-center gap-1"><MessageSquare size={10} />SMS sent</span>}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

