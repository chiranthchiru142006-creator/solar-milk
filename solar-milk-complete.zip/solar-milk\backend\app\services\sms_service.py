import logging
import httpx
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.config import settings
from app.models.sms_log import SMSLog

logger = logging.getLogger("solar_milk.sms")

FARMER_PHONE_MAP = {
    "f_chiranth": "9686720081",
    "f_anisha":   "8151920063",
}

FAST2SMS_URL = "https://www.fast2sms.com/dev/bulkV2"


def _send_fast2sms(mobile: str, message: str) -> tuple:
    if not settings.FAST2SMS_API_KEY:
        return False, "FAST2SMS_API_KEY not set in backend/.env"
    try:
        resp = httpx.post(
            FAST2SMS_URL,
            headers={"authorization": settings.FAST2SMS_API_KEY, "Content-Type": "application/json"},
            json={"route": settings.FAST2SMS_MESSAGE_ROUTE, "message": message, "language": "english", "flash": 0, "numbers": mobile},
            timeout=10.0,
        )
        data = resp.json()
        if resp.status_code == 200 and data.get("return") is True:
            return True, ""
        return False, str(data.get("message", data))
    except Exception as exc:
        return False, str(exc)


def _send_twilio(mobile: str, message: str) -> tuple:
    try:
        url = f"https://api.twilio.com/2010-04-01/Accounts/{settings.TWILIO_ACCOUNT_SID}/Messages.json"
        resp = httpx.post(url, data={"From": settings.TWILIO_FROM_NUMBER, "To": f"+91{mobile}", "Body": message},
                          auth=(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN), timeout=8.0)
        return resp.status_code in (200, 201), ""
    except Exception as exc:
        return False, str(exc)


class SMSService:
    @staticmethod
    def send_alert_sms(db: Session, farmer_id: str, farmer_name: str, message: str, condition_key: Optional[str] = None) -> Dict[str, Any]:
        expected_mobile = FARMER_PHONE_MAP.get(farmer_id)
        if not expected_mobile:
            return {"success": False, "status": "failed", "error": "Unregistered farmer"}

        now = datetime.now(timezone.utc)

        if condition_key:
            cutoff = now - timedelta(minutes=settings.SMS_COOLDOWN_MINUTES)
            recent = db.query(SMSLog).filter(
                SMSLog.farmer_id == farmer_id, SMSLog.condition_key == condition_key,
                SMSLog.status == "sent", SMSLog.sent_at >= cutoff
            ).first()
            if recent:
                db.add(SMSLog(farmer_id=farmer_id, mobile=expected_mobile, message=message, status="suppressed_cooldown", condition_key=condition_key, sent_at=now))
                db.commit()
                return {"success": True, "status": "suppressed_cooldown", "recipient": expected_mobile}

        mode = settings.SMS_MODE.lower()
        ok, err = False, ""

        if mode == "fast2sms":
            ok, err = _send_fast2sms(expected_mobile, message)
        elif mode == "twilio" and settings.TWILIO_ACCOUNT_SID:
            ok, err = _send_twilio(expected_mobile, message)
        else:
            print(f"\n{'='*60}\n[SMS MOCK] To: +91{expected_mobile} ({farmer_name})\n{message}\n{'='*60}\n")
            ok = True

        status = "sent" if ok else "failed"
        db.add(SMSLog(farmer_id=farmer_id, mobile=expected_mobile, message=message, status=status, condition_key=condition_key or "general", sent_at=now))
        db.commit()
        return {"success": ok, "status": status, "recipient": expected_mobile, "error": err}


sms_service = SMSService()

