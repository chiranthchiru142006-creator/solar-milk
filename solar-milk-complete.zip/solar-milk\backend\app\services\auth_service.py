from datetime import datetime, timedelta, timezone
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from app.config import settings
from app.models.farmer import Farmer

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)

def hash_password(plain: str) -> str:
    return pwd_context.hash(plain)

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode["exp"] = expire
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

def decode_token(token: str) -> dict:
    return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])

def authenticate_farmer(db: Session, mobile: str, password: str):
    farmer = db.query(Farmer).filter(Farmer.mobile == mobile).first()
    if not farmer or not verify_password(password, farmer.hashed_password):
        return None
    return farmer

def get_current_farmer(db: Session, token: str):
    try:
        payload = decode_token(token)
        farmer_id = payload.get("sub")
        if not farmer_id:
            return None
        return db.query(Farmer).filter(Farmer.id == farmer_id).first()
    except JWTError:
        return None
