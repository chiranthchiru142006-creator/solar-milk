from pydantic import BaseModel

class Token(BaseModel):
    access_token: str
    token_type: str
    farmer_id: str
    farmer_name: str
    mobile: str

class FarmerProfile(BaseModel):
    id: str
    name: str
    mobile: str
    is_active: bool

    class Config:
        from_attributes = True
