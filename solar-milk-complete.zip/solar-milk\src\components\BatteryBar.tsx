import React from 'react'

interface Props {
  voltage: number
  minV?: number
  maxV?: number
}

export default function BatteryBar({ voltage, minV = 10.5, maxV = 14.4 }: Props) {
  const pct = Math.min(100, Math.max(0, ((voltage - minV) / (maxV - minV)) * 100))
  const color = pct > 50 ? 'bg-green-500' : pct > 25 ? 'bg-yellow-400' : 'bg-red-500'
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-3 bg-gray-200 rounded-full overflow-hidden">
        <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs text-gray-500 w-10 text-right">{voltage.toFixed(1)}V</span>
    </div>
  )
}
