from sqlalchemy.orm import Session
from app.models.farmer import Farmer
from app.models.milk_can import MilkCan
from app.models.telemetry import TelemetryReading
from app.services.auth_service import hash_password
from datetime import datetime, timezone, timedelta
import random

FARMERS = [
    {"id": "f_chiranth", "name": "Chiranth U", "mobile": "9686720081"},
    {"id": "f_anisha",   "name": "Anisha M",   "mobile": "8151920063"},
]

CANS = [
    {"id": "can_chiranth_1", "name": "Chiranth 1", "farmer_id": "f_chiranth"},
    {"id": "can_anisha_1",   "name": "Anisha 1",   "farmer_id": "f_anisha"},
]

def seed_database(db: Session):
    for f in FARMERS:
        if not db.query(Farmer).filter(Farmer.id == f["id"]).first():
            db.add(Farmer(id=f["id"], name=f["name"], mobile=f["mobile"], hashed_password=hash_password(f["mobile"])))

    for c in CANS:
        if not db.query(MilkCan).filter(MilkCan.id == c["id"]).first():
            db.add(MilkCan(id=c["id"], name=c["name"], farmer_id=c["farmer_id"]))

    db.commit()

    for c in CANS:
        count = db.query(TelemetryReading).filter(TelemetryReading.can_id == c["id"]).count()
        if count < 20:
            now = datetime.now(timezone.utc)
            for i in range(20):
                db.add(TelemetryReading(
                    can_id=c["id"],
                    timestamp=now - timedelta(minutes=5 * i),
                    temperature_c=round(3.5 + random.uniform(0, 2), 2),
                    battery_voltage=round(12.0 + random.uniform(-0.5, 0.8), 2),
                    solar_voltage=round(17.5 + random.uniform(-2, 3), 2),
                    milk_quantity_litres=round(24 + random.uniform(-2, 4), 1),
                    bluetooth_connected=True,
                    battery_temperature_c=round(30 + random.uniform(-3, 5), 1),
                    signal_strength_dbm=random.randint(-75, -45),
                ))
    db.commit()
    print("[Seed] Database seeded: 2 farmers, 2 cans, 20 telemetry readings each.")

