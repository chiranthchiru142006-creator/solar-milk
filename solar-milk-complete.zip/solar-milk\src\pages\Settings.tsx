import React, { useState } from 'react'
import { Settings as SettingsIcon, User, Bell, Wifi, Info, CheckCircle2 } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function Settings() {
  const { farmerName, mobile, currentCan, wsConnected } = useApp()
  const [smsAlerts, setSmsAlerts] = useState(true)
  const [tempThreshold, setTempThreshold] = useState(8)
  const [saved, setSaved] = useState(false)

  const save = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <SettingsIcon className="text-gray-500" size={28} />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-500 text-sm">Configuration for {farmerName}</p>
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 space-y-4">
        <h2 className="text-sm font-semibold text-gray-700 flex items-center gap-2"><User size={16} />Farmer Profile</h2>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><p className="text-gray-400 text-xs">Name</p><p className="font-medium">{farmerName}</p></div>
          <div><p className="text-gray-400 text-xs">Mobile</p><p className="font-medium">+91 {mobile}</p></div>
          <div><p className="text-gray-400 text-xs">Milk Can</p><p className="font-medium">{currentCan?.can_name}</p></div>
          <div><p className="text-gray-400 text-xs">Can ID</p><p className="font-medium font-mono text-xs">{currentCan?.can_id}</p></div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 space-y-4">
        <h2 className="text-sm font-semibold text-gray-700 flex items-center gap-2"><Bell size={16} />Alert Settings</h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">SMS Alerts</p>
            <p className="text-xs text-gray-400">Receive SMS on critical events</p>
          </div>
          <button
            onClick={() => setSmsAlerts(v => !v)}
            className={`w-11 h-6 rounded-full transition-colors relative ${smsAlerts ? 'bg-green-600' : 'bg-gray-300'}`}
          >
            <div className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${smsAlerts ? 'translate-x-5' : ''}`} />
          </button>
        </div>
        <div>
          <label className="text-sm font-medium">Temperature Warning Threshold: {tempThreshold}°C</label>
          <input type="range" min={4} max={16} value={tempThreshold}
            onChange={e => setTempThreshold(Number(e.target.value))}
            className="w-full mt-2 accent-green-600" />
          <div className="flex justify-between text-xs text-gray-400 mt-1"><span>4°C</span><span>16°C</span></div>
        </div>
        <button onClick={save} className="w-full py-2 bg-green-700 text-white rounded-lg text-sm font-medium hover:bg-green-800 flex items-center justify-center gap-2">
          {saved ? <><CheckCircle2 size={15} />Saved!</> : 'Save Settings'}
        </button>
      </div>

      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 space-y-3">
        <h2 className="text-sm font-semibold text-gray-700 flex items-center gap-2"><Wifi size={16} />Connection Status</h2>
        <div className="flex items-center gap-2 text-sm">
          <div className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-green-500' : 'bg-yellow-400'}`} />
          {wsConnected ? 'WebSocket live stream active' : 'Polling mode (30s interval)'}
        </div>
        <div className="text-xs text-gray-400 space-y-1">
          <p>Backend:   http://localhost:8000</p>
          <p>Frontend:  http://localhost:5173</p>
          <p>WebSocket: ws://localhost:8000/ws/telemetry</p>
          <p>API Docs:  http://localhost:8000/docs</p>
        </div>
      </div>

      <div className="bg-green-50 rounded-xl p-4 border border-green-200">
        <div className="flex items-start gap-2">
          <Info size={16} className="text-green-700 mt-0.5 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-green-800">Enable Real SMS (Fast2SMS)</p>
            <p className="text-xs text-green-700 mt-1 space-y-1">
              1. Sign up free at <strong>fast2sms.com</strong><br />
              2. Copy API key from Dashboard → Dev API<br />
              3. Edit <code className="bg-green-100 px-1 rounded">backend/.env</code>:<br />
              &nbsp;&nbsp;<code className="bg-green-100 px-1 rounded">SMS_MODE=fast2sms</code><br />
              &nbsp;&nbsp;<code className="bg-green-100 px-1 rounded">FAST2SMS_API_KEY=your_key_here</code><br />
              4. Restart the backend
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

