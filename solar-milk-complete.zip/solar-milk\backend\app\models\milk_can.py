from sqlalchemy import Column, String, Float, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from app.database import Base

class MilkCan(Base):
    __tablename__ = "milk_cans"
    id               = Column(String, primary_key=True, index=True)
    name             = Column(String, nullable=False)
    farmer_id        = Column(String, ForeignKey("farmers.id"), nullable=False)
    location         = Column(String, default="")
    capacity_litres  = Column(Float, default=50.0)
    is_active        = Column(Boolean, default=True)
    created_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    farmer           = relationship("Farmer", back_populates="milk_cans")
    telemetry        = relationship("TelemetryReading", back_populates="milk_can")
    alerts           = relationship("Alert", back_populates="milk_can")

