from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from app.database import SessionLocal
from app.services.auth_service import get_current_farmer
from app.services.telemetry_service import get_latest, derive_status
import asyncio

router = APIRouter()

class ConnectionManager:
    def __init__(self):
        self.active: dict[str, list[WebSocket]] = {}

    async def connect(self, farmer_id: str, ws: WebSocket):
        await ws.accept()
        self.active.setdefault(farmer_id, []).append(ws)

    def disconnect(self, farmer_id: str, ws: WebSocket):
        if farmer_id in self.active:
            try:
                self.active[farmer_id].remove(ws)
            except ValueError:
                pass

    async def broadcast_to_farmer(self, farmer_id: str, data: dict):
        for ws in list(self.active.get(farmer_id, [])):
            try:
                await ws.send_json(data)
            except Exception:
                pass


manager = ConnectionManager()

@router.websocket("/ws/telemetry")
async def ws_telemetry(websocket: WebSocket, token: str = Query(...)):
    db = SessionLocal()
    farmer = get_current_farmer(db, token)
    if not farmer:
        await websocket.close(code=4001)
        db.close()
        return

    can_id = "can_chiranth_1" if farmer.id == "f_chiranth" else "can_anisha_1"
    await manager.connect(farmer.id, websocket)
    try:
        while True:
            await asyncio.sleep(10)
            latest = get_latest(db, can_id)
            if latest:
                await websocket.send_json({
                    "type": "telemetry_update",
                    "status": derive_status(latest),
                    "data": {
                        "id": latest.id,
                        "timestamp": latest.timestamp.isoformat(),
                        "can_id": latest.can_id,
                        "temperature_c": latest.temperature_c,
                        "battery_voltage": latest.battery_voltage,
                        "solar_voltage": latest.solar_voltage,
                        "milk_quantity_litres": latest.milk_quantity_litres,
                        "bluetooth_connected": latest.bluetooth_connected,
                        "battery_temperature_c": latest.battery_temperature_c,
                        "signal_strength_dbm": latest.signal_strength_dbm,
                    }
                })
    except WebSocketDisconnect:
        manager.disconnect(farmer.id, websocket)
    finally:
        db.close()

