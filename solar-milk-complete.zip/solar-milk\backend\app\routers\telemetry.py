from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.services.auth_service import get_current_farmer
from app.services import telemetry_service, alert_service
from app.services.sms_service import sms_service
from app.schemas.telemetry import TelemetryIngest, TelemetryOut
from app.models.milk_can import MilkCan
from app.models.alert import Alert

router = APIRouter(prefix="/telemetry", tags=["telemetry"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

def verify_can_access(farmer, can_id: str, db: Session):
    can = db.query(MilkCan).filter(MilkCan.id == can_id).first()
    if not can:
        raise HTTPException(status_code=404, detail="Can not found")
    if can.farmer_id != farmer.id:
        raise HTTPException(status_code=403, detail="Access denied")
    return can

@router.post("/ingest", response_model=TelemetryOut)
def ingest(payload: TelemetryIngest, token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    farmer = get_current_farmer(db, token)
    if not farmer:
        raise HTTPException(status_code=401, detail="Unauthorized")
    can = verify_can_access(farmer, payload.can_id, db)
    reading = telemetry_service.ingest(db, payload)
    alerts = alert_service.evaluate_and_create_alerts(db, reading, farmer.id, can.name)
    for alert in alerts:
        sms_service.send_alert_sms(db, farmer.id, farmer.name, alert.message, alert.alert_type)
    return reading

@router.get("/can/{can_id}/status")
def can_status(can_id: str, token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    farmer = get_current_farmer(db, token)
    if not farmer:
        raise HTTPException(status_code=401, detail="Unauthorized")
    can = verify_can_access(farmer, can_id, db)
    latest = telemetry_service.get_latest(db, can_id)
    status = telemetry_service.derive_status(latest)
    alerts_count = db.query(Alert).filter_by(can_id=can_id, is_resolved=False).count()
    return {
        "can_id": can.id,
        "can_name": can.name,
        "farmer_name": farmer.name,
        "latest": {
            "id": latest.id, "timestamp": latest.timestamp.isoformat(), "can_id": latest.can_id,
            "temperature_c": latest.temperature_c, "battery_voltage": latest.battery_voltage,
            "solar_voltage": latest.solar_voltage, "milk_quantity_litres": latest.milk_quantity_litres,
            "bluetooth_connected": latest.bluetooth_connected,
            "battery_temperature_c": latest.battery_temperature_c,
            "signal_strength_dbm": latest.signal_strength_dbm,
        } if latest else None,
        "status": status,
        "alerts_count": alerts_count,
    }

@router.get("/can/{can_id}/history", response_model=List[TelemetryOut])
def can_history(can_id: str, limit: int = 50, token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    farmer = get_current_farmer(db, token)
    if not farmer:
        raise HTTPException(status_code=401, detail="Unauthorized")
    verify_can_access(farmer, can_id, db)
    return telemetry_service.get_history(db, can_id, limit)

@router.get("/system/status")
def system_status(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    farmer = get_current_farmer(db, token)
    if not farmer:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {"farmer": farmer.name, "status": "operational", "backend": "FastAPI", "db": "SQLite"}

