import axios from 'axios'

const BASE = '/api'

export interface LoginResponse {
  access_token: string
  token_type: string
  farmer_id: string
  farmer_name: string
  mobile: string
}

export async function login(mobile: string, password: string): Promise<LoginResponse> {
  const form = new URLSearchParams()
  form.append('username', mobile)
  form.append('password', password)
  const { data } = await axios.post<LoginResponse>(`${BASE}/auth/login`, form, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  })
  return data
}

export async function getProfile(token: string) {
  const { data } = await axios.get(`${BASE}/auth/me`, {
    headers: { Authorization: `Bearer ${token}` },
  })
  return data
}
