import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.main import app
from app.database import Base, get_db
from app.seed import seed_database

TEST_DB = "sqlite:///./test_solar_milk.db"
engine = create_engine(TEST_DB, connect_args={"check_same_thread": False})
TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base.metadata.create_all(bind=engine)
db = TestingSession()
seed_database(db)
db.close()

def override_get_db():
    db = TestingSession()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)

def get_token(mobile: str):
    r = client.post("/api/auth/login", data={"username": mobile, "password": mobile})
    return r.json()["access_token"]

def test_root():
    r = client.get("/")
    assert r.status_code == 200
    assert "operational" in r.json()["status"]

def test_health():
    r = client.get("/health")
    assert r.status_code == 200

def test_login_chiranth():
    r = client.post("/api/auth/login", data={"username": "9686720081", "password": "9686720081"})
    assert r.status_code == 200
    assert r.json()["farmer_id"] == "f_chiranth"

def test_login_anisha():
    r = client.post("/api/auth/login", data={"username": "8151920063", "password": "8151920063"})
    assert r.status_code == 200
    assert r.json()["farmer_id"] == "f_anisha"

def test_login_wrong_password():
    r = client.post("/api/auth/login", data={"username": "9686720081", "password": "wrong"})
    assert r.status_code == 401

def test_me():
    token = get_token("9686720081")
    r = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert r.json()["name"] == "Chiranth U"

def test_can_status_chiranth():
    token = get_token("9686720081")
    r = client.get("/api/telemetry/can/can_chiranth_1/status", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert r.json()["can_id"] == "can_chiranth_1"

def test_isolation_chiranth_cannot_see_anisha():
    token = get_token("9686720081")
    r = client.get("/api/telemetry/can/can_anisha_1/status", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 403

def test_ingest_telemetry():
    token = get_token("9686720081")
    payload = {"can_id": "can_chiranth_1", "temperature_c": 5.0, "battery_voltage": 12.5, "solar_voltage": 18.0, "milk_quantity_litres": 25.0, "bluetooth_connected": True}
    r = client.post("/api/telemetry/ingest", json=payload, headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert r.json()["temperature_c"] == 5.0

def test_history():
    token = get_token("9686720081")
    r = client.get("/api/telemetry/can/can_chiranth_1/history?limit=5", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert isinstance(r.json(), list)

def test_alerts():
    token = get_token("9686720081")
    r = client.get("/api/alerts/can/can_chiranth_1", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200

def test_system_status():
    token = get_token("9686720081")
    r = client.get("/api/telemetry/system/status", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200

