import axios from 'axios'

const BASE = '/api'

function authHeader(token: string) {
  return { Authorization: `Bearer ${token}` }
}

export interface TelemetryPayload {
  can_id: string
  temperature_c: number
  battery_voltage: number
  solar_voltage: number
  milk_quantity_litres: number
  bluetooth_connected: boolean
  battery_temperature_c?: number
  signal_strength_dbm?: number
}

export async function getCanStatus(token: string, canId: string) {
  const { data } = await axios.get(`${BASE}/telemetry/can/${canId}/status`, {
    headers: authHeader(token),
  })
  return data
}

export async function getCanHistory(token: string, canId: string, limit = 50) {
  const { data } = await axios.get(`${BASE}/telemetry/can/${canId}/history?limit=${limit}`, {
    headers: authHeader(token),
  })
  return data
}

export async function ingestTelemetry(token: string, payload: TelemetryPayload) {
  const { data } = await axios.post(`${BASE}/telemetry/ingest`, payload, {
    headers: authHeader(token),
  })
  return data
}

export async function getAlerts(token: string, canId: string) {
  const { data } = await axios.get(`${BASE}/alerts/can/${canId}`, {
    headers: authHeader(token),
  })
  return data
}

export async function getSystemStatus(token: string) {
  const { data } = await axios.get(`${BASE}/telemetry/system/status`, {
    headers: authHeader(token),
  })
  return data
}
