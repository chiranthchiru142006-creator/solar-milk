from sqlalchemy.orm import Session
from app.models.alert import Alert
from app.models.telemetry import TelemetryReading

def evaluate_and_create_alerts(db: Session, reading: TelemetryReading, farmer_id: str, can_name: str) -> list:
    new_alerts = []

    if reading.temperature_c > 12:
        alert = Alert(
            can_id=reading.can_id,
            alert_type="high_temperature_critical",
            message=f"CRITICAL: {can_name} temperature is {reading.temperature_c:.1f}C. Milk at risk!",
            severity="critical",
        )
        db.add(alert)
        new_alerts.append(alert)
    elif reading.temperature_c > 8:
        alert = Alert(
            can_id=reading.can_id,
            alert_type="high_temperature_warning",
            message=f"WARNING: {can_name} temperature is {reading.temperature_c:.1f}C. Check cooling.",
            severity="warning",
        )
        db.add(alert)
        new_alerts.append(alert)

    if reading.battery_voltage < 11.0:
        alert = Alert(
            can_id=reading.can_id,
            alert_type="battery_critical",
            message=f"CRITICAL: {can_name} battery {reading.battery_voltage:.1f}V. System may shut down!",
            severity="critical",
        )
        db.add(alert)
        new_alerts.append(alert)
    elif reading.battery_voltage < 11.5:
        alert = Alert(
            can_id=reading.can_id,
            alert_type="battery_warning",
            message=f"LOW BATTERY: {can_name} at {reading.battery_voltage:.1f}V. Charge soon.",
            severity="warning",
        )
        db.add(alert)
        new_alerts.append(alert)

    if not reading.bluetooth_connected:
        alert = Alert(
            can_id=reading.can_id,
            alert_type="bluetooth_disconnected",
            message=f"Bluetooth disconnected on {can_name}. Sensor data may be interrupted.",
            severity="warning",
        )
        db.add(alert)
        new_alerts.append(alert)

    db.commit()
    return new_alerts

def get_alerts_for_can(db: Session, can_id: str, limit: int = 50):
    return (
        db.query(Alert)
        .filter(Alert.can_id == can_id)
        .order_by(Alert.created_at.desc())
        .limit(limit)
        .all()
    )
