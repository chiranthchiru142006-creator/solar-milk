from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from app.database import Base

class Alert(Base):
    __tablename__ = "alerts"
    id          = Column(Integer, primary_key=True, index=True, autoincrement=True)
    can_id      = Column(String, ForeignKey("milk_cans.id"), nullable=False, index=True)
    alert_type  = Column(String, nullable=False)
    message     = Column(String, nullable=False)
    severity    = Column(String, default="warning")
    is_resolved = Column(Boolean, default=False)
    sms_sent    = Column(Boolean, default=False)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    resolved_at = Column(DateTime, nullable=True)
    milk_can    = relationship("MilkCan", back_populates="alerts")

