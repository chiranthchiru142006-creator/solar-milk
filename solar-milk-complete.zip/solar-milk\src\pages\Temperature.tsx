import React from 'react'
import { Thermometer, TrendingDown, TrendingUp, AlertTriangle, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'

export default function Temperature() {
  const { currentCan, history } = useApp()
  const t = currentCan?.latest

  const chartData = [...history].reverse().slice(-30).map((p) => ({
    time: new Date(p.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    temp: Number(p.temperature_c.toFixed(2)),
  }))

  const temps = history.map(p => p.temperature_c)
  const minTemp = temps.length ? Math.min(...temps).toFixed(1) : '—'
  const maxTemp = temps.length ? Math.max(...temps).toFixed(1) : '—'
  const avgTemp = temps.length ? (temps.reduce((a, b) => a + b, 0) / temps.length).toFixed(1) : '—'
  const status = !t ? 'offline' : t.temperature_c < 8 ? 'safe' : t.temperature_c < 12 ? 'warning' : 'critical'

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Thermometer className="text-blue-500" size={28} />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Temperature Analytics</h1>
          <p className="text-gray-500 text-sm">Milk preservation monitoring for {currentCan?.can_name}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-center">
          <TrendingDown size={18} className="text-blue-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-gray-900">{minTemp}°C</p>
          <p className="text-xs text-gray-500">Minimum</p>
        </div>
        <div className={`rounded-xl p-4 shadow-sm border text-center ${
          status === 'safe' ? 'bg-green-50 border-green-200' : status === 'warning' ? 'bg-yellow-50 border-yellow-200' : 'bg-red-50 border-red-200'
        }`}>
          {status === 'safe'
            ? <CheckCircle2 size={18} className="text-green-600 mx-auto mb-1" />
            : <AlertTriangle size={18} className={`mx-auto mb-1 ${status === 'warning' ? 'text-yellow-600' : 'text-red-600'}`} />}
          <p className="text-2xl font-bold">{t ? `${t.temperature_c.toFixed(1)}°C` : '—'}</p>
          <p className="text-xs text-gray-500">Current</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-center">
          <TrendingUp size={18} className="text-red-500 mx-auto mb-1" />
          <p className="text-2xl font-bold text-gray-900">{maxTemp}°C</p>
          <p className="text-xs text-gray-500">Maximum</p>
        </div>
      </div>

      {chartData.length > 1 && (
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <h2 className="text-sm font-semibold text-gray-700 mb-4">Temperature History ({chartData.length} readings)</h2>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={chartData} margin={{ top: 10, right: 20, bottom: 5, left: 0 }}>
              <defs>
                <linearGradient id="tempFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="time" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} domain={[0, 20]} unit="°C" />
              <Tooltip formatter={(v: number) => [`${v}°C`, 'Temp']} />
              <ReferenceLine y={8}  stroke="#f59e0b" strokeDasharray="4 4" label={{ value: 'Warn 8°C',     fontSize: 10 }} />
              <ReferenceLine y={12} stroke="#ef4444" strokeDasharray="4 4" label={{ value: 'Critical 12°C', fontSize: 10 }} />
              <Area type="monotone" dataKey="temp" stroke="#3b82f6" fill="url(#tempFill)" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
            </AreaChart>
          </ResponsiveContainer>
          <p className="text-xs text-gray-400 mt-2">Average: <strong>{avgTemp}°C</strong></p>
        </div>
      )}

      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <ShieldCheck size={18} className="text-green-600" />
          <h2 className="text-sm font-semibold text-gray-700">Dairy Preservation Guidelines</h2>
        </div>
        <div className="space-y-3">
          {[
            { range: '0–4°C',  color: 'bg-blue-100 text-blue-800',    icon: Sparkles,      label: 'Optimal — Maximum freshness', days: '5–7 days' },
            { range: '4–8°C',  color: 'bg-green-100 text-green-800',  icon: CheckCircle2,  label: 'Safe — Good preservation',    days: '3–5 days' },
            { range: '8–12°C', color: 'bg-yellow-100 text-yellow-800', icon: AlertTriangle, label: 'Warning — Inspect soon',       days: '1–2 days' },
            { range: '>12°C',  color: 'bg-red-100 text-red-800',      icon: AlertTriangle, label: 'Critical — Risk of spoilage',  days: 'Hours' },
          ].map(({ range, color, icon: Icon, label, days }) => (
            <div key={range} className={`flex items-center justify-between p-3 rounded-lg ${color}`}>
              <div className="flex items-center gap-2">
                <Icon size={14} />
                <span className="font-semibold text-sm">{range}</span>
                <span className="text-sm">{label}</span>
              </div>
              <span className="text-xs font-medium">{days}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

