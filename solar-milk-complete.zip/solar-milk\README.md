# 🥛 Solar Milk – Smart Dairy IoT Monitoring System

A full-stack IoT monitoring platform for solar-powered milk preservation cans.

## Features
- Real-time telemetry: temperature, battery, solar voltage, Bluetooth status
- JWT authentication with per-farmer data isolation
- WebSocket live updates
- SMS alerts via Fast2SMS (Indian SMS gateway)
- Hardware simulation bar for testing
- Recharts analytics dashboards

## Registered Farmers
| Farmer | Mobile | Milk Can |
|---|---|---|
| Chiranth U | 9686720081 | Chiranth 1 |
| Anisha M | 8151920063 | Anisha 1 |

## Quick Start

### Backend
```bash
cd backend
python -m venv .venv
.venv\Scripts\activate        # Windows
pip install -r requirements.txt
python run.py
```
Backend runs at: http://localhost:8000
API Docs: http://localhost:8000/docs

### Frontend
```bash
npm install
npm run dev
```
Frontend runs at: http://localhost:5173

## SMS Integration (Fast2SMS)
1. Sign up at https://www.fast2sms.com
2. Get your API key from Dashboard → Dev API
3. Edit `backend/.env`: set `SMS_MODE=fast2sms` and `FAST2SMS_API_KEY=your_key`
4. Restart backend

## Architecture
```
Browser (5173) ──/api/──► FastAPI (8000) ──► SQLite
               ──/ws/───► WebSocket ◄────── BLE / Simulator
```
