import React from 'react'
import { NavLink } from 'react-router-dom'
import {
  Milk, LayoutDashboard, Thermometer, BatteryCharging,
  Bluetooth, Bell, Settings, LogOut, Wifi, WifiOff,
} from 'lucide-react'
import { useApp } from '../context/AppContext'

const NAV = [
  { to: '/dashboard',    icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/my-can',       icon: Milk,            label: 'My Milk Can' },
  { to: '/temperature',  icon: Thermometer,     label: 'Temperature' },
  { to: '/battery-solar',icon: BatteryCharging, label: 'Battery & Solar' },
  { to: '/bluetooth',    icon: Bluetooth,       label: 'Bluetooth' },
  { to: '/alerts',       icon: Bell,            label: 'Alerts' },
  { to: '/settings',     icon: Settings,        label: 'Settings' },
]

export default function Sidebar() {
  const { farmerName, mobile, wsConnected, logout } = useApp()
  return (
    <aside className="w-64 bg-green-900 text-white flex flex-col h-full">
      <div className="p-5 border-b border-green-800">
        <div className="flex items-center gap-2 mb-1">
          <Milk className="text-green-300" size={22} />
          <span className="font-bold text-lg tracking-tight">Solar Milk</span>
        </div>
        <p className="text-green-400 text-xs">Smart Dairy Monitoring</p>
      </div>
      <div className="px-4 py-3 border-b border-green-800">
        <p className="text-sm font-semibold text-white">{farmerName}</p>
        <p className="text-xs text-green-400">+91 {mobile}</p>
        <div className="flex items-center gap-1 mt-1">
          {wsConnected
            ? <><Wifi size={12} className="text-green-400" /><span className="text-xs text-green-400">Live</span></>
            : <><WifiOff size={12} className="text-yellow-400" /><span className="text-xs text-yellow-400">Polling</span></>
          }
        </div>
      </div>
      <nav className="flex-1 py-3 overflow-y-auto">
        {NAV.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-5 py-2.5 text-sm transition-colors ${
                isActive
                  ? 'bg-green-700 text-white font-medium'
                  : 'text-green-200 hover:bg-green-800 hover:text-white'
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>
      <button
        onClick={logout}
        className="flex items-center gap-3 px-5 py-3 text-sm text-green-300 hover:bg-green-800 hover:text-white transition-colors border-t border-green-800"
      >
        <LogOut size={18} />
        Logout
      </button>
    </aside>
  )
}
