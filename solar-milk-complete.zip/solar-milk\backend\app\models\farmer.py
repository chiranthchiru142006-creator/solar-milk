from sqlalchemy import Column, String, Boolean, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from app.database import Base

class Farmer(Base):
    __tablename__ = "farmers"
    id              = Column(String, primary_key=True, index=True)
    name            = Column(String, nullable=False)
    mobile          = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    is_active       = Column(Boolean, default=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    milk_cans       = relationship("MilkCan", back_populates="farmer")

