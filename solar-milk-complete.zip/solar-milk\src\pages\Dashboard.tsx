import React from 'react'
import { useNavigate } from 'react-router-dom'
import { Thermometer, BatteryCharging, Sun, Milk, Bluetooth, Bell, RefreshCw } from 'lucide-react'
import { useApp } from '../context/AppContext'
import StatusBadge from '../components/StatusBadge'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'

export default function Dashboard() {
  const { farmerName, currentCan, history, refreshFarmerData } = useApp()
  const nav = useNavigate()
  const t = currentCan?.latest

  const chartData = [...history].reverse().slice(-20).map((p) => ({
    temp: Number(p.temperature_c?.toFixed(1)),
    time: new Date(p.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
  }))

  const cards = [
    { label: 'Temperature',  value: t ? `${t.temperature_c.toFixed(1)}°C` : '—',           icon: Thermometer,   color: 'text-blue-500',   to: '/temperature' },
    { label: 'Battery',      value: t ? `${t.battery_voltage.toFixed(1)}V` : '—',           icon: BatteryCharging, color: 'text-green-500', to: '/battery-solar' },
    { label: 'Solar',        value: t ? `${t.solar_voltage.toFixed(1)}V` : '—',             icon: Sun,           color: 'text-yellow-500', to: '/battery-solar' },
    { label: 'Milk',         value: t ? `${t.milk_quantity_litres.toFixed(1)}L` : '—',      icon: Milk,          color: 'text-cyan-500',   to: '/my-can' },
    { label: 'Bluetooth',    value: t ? (t.bluetooth_connected ? 'Connected' : 'Off') : '—', icon: Bluetooth,    color: 'text-purple-500', to: '/bluetooth' },
    { label: 'Alerts',       value: `${currentCan?.alerts_count ?? 0}`,                      icon: Bell,          color: 'text-red-500',    to: '/alerts' },
  ]

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Welcome, {farmerName} 👋</h1>
          <p className="text-gray-500 text-sm mt-1 flex items-center gap-2">
            {currentCan?.can_name ?? 'Loading…'}
            {currentCan && <StatusBadge status={currentCan.status} size="sm" />}
          </p>
        </div>
        <button onClick={refreshFarmerData} className="flex items-center gap-2 px-4 py-2 bg-green-700 text-white rounded-lg text-sm hover:bg-green-800 transition-colors">
          <RefreshCw size={15} /> Refresh
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {cards.map(({ label, value, icon: Icon, color, to }) => (
          <button key={label} onClick={() => nav(to)} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all text-left">
            <div className="flex items-center gap-2 mb-2">
              <Icon size={18} className={color} />
              <span className="text-xs text-gray-500 font-medium">{label}</span>
            </div>
            <p className="text-xl font-bold text-gray-900">{value}</p>
          </button>
        ))}
      </div>

      {chartData.length > 1 && (
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <h2 className="text-sm font-semibold text-gray-700 mb-4">Temperature Trend</h2>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={chartData} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
              <defs>
                <linearGradient id="tempGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="time" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} domain={[0, 20]} unit="°C" />
              <Tooltip formatter={(v: number) => [`${v}°C`, 'Temperature']} />
              <ReferenceLine y={8}  stroke="#f59e0b" strokeDasharray="4 4" label={{ value: 'Warn',     position: 'right', fontSize: 10 }} />
              <ReferenceLine y={12} stroke="#ef4444" strokeDasharray="4 4" label={{ value: 'Critical', position: 'right', fontSize: 10 }} />
              <Area type="monotone" dataKey="temp" stroke="#3b82f6" fill="url(#tempGrad)" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  )
}

