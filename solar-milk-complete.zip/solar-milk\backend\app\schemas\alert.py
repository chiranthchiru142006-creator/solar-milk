from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class AlertOut(BaseModel):
    id: int
    can_id: str
    alert_type: str
    message: str
    severity: str
    is_resolved: bool
    sms_sent: bool
    created_at: datetime
    resolved_at: Optional[datetime] = None

    class Config:
        from_attributes = True
