from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.services.auth_service import get_current_farmer
from app.services.alert_service import get_alerts_for_can
from app.schemas.alert import AlertOut
from app.models.milk_can import MilkCan

router = APIRouter(prefix="/alerts", tags=["alerts"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

@router.get("/can/{can_id}", response_model=List[AlertOut])
def get_alerts(can_id: str, token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    farmer = get_current_farmer(db, token)
    if not farmer:
        raise HTTPException(status_code=401, detail="Unauthorized")
    can = db.query(MilkCan).filter(MilkCan.id == can_id).first()
    if not can or can.farmer_id != farmer.id:
        raise HTTPException(status_code=403, detail="Access denied")
    return get_alerts_for_can(db, can_id)

