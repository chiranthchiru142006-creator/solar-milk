import React, { useState } from 'react'
import { Bluetooth, Wifi, RefreshCw, CheckCircle2, Radio, Clock, ShieldCheck, Layers, HelpCircle } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function BluetoothStatus() {
  const { currentCan, simulateScenario, isSimulating } = useApp()
  const [reconnecting, setReconnecting] = useState(false)
  const t = currentCan?.latest

  const isConnected = t?.bluetooth_connected ?? false
  const signal      = t?.signal_strength_dbm ?? null
  const signalPct   = signal !== null ? Math.min(100, Math.max(0, (signal + 100) / 70 * 100)) : 0

  const triggerReconnect = async () => {
    setReconnecting(true)
    await simulateScenario('normal')
    setReconnecting(false)
  }

  const gattServices = [
    { uuid: '19b10000-e8f2-537e-4f6c-d104768a1214', name: 'Telemetry Service',         active: isConnected },
    { uuid: '19b10001-e8f2-537e-4f6c-d104768a1214', name: 'Temperature Characteristic', active: isConnected },
    { uuid: '19b10002-e8f2-537e-4f6c-d104768a1214', name: 'Control Characteristic',     active: isConnected },
  ]

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bluetooth className={isConnected ? 'text-blue-500' : 'text-gray-400'} size={28} />
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Bluetooth Status</h1>
            <p className="text-gray-500 text-sm">BLE GATT diagnostics for {currentCan?.can_name}</p>
          </div>
        </div>
        {!isConnected && (
          <button
            disabled={isSimulating || reconnecting}
            onClick={triggerReconnect}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 disabled:opacity-50"
          >
            <RefreshCw size={15} className={reconnecting ? 'animate-spin' : ''} />
            Reconnect
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className={`rounded-xl p-5 shadow-sm border ${isConnected ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            {isConnected
              ? <CheckCircle2 className="text-blue-600" size={18} />
              : <Bluetooth className="text-gray-400" size={18} />}
            <span className="font-semibold text-sm">{isConnected ? 'BLE Connected' : 'BLE Disconnected'}</span>
          </div>
          <p className="text-xs text-gray-500">Device: Solar Milk Can</p>
          {t && <p className="text-xs text-gray-400 mt-1">Last seen: {new Date(t.timestamp).toLocaleTimeString('en-IN')}</p>}
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <Wifi size={18} className="text-purple-500" />
            <span className="font-semibold text-sm">Signal Strength</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{signal !== null ? `${signal} dBm` : '—'}</p>
          <div className="h-2 bg-gray-200 rounded-full mt-2 overflow-hidden">
            <div className="h-full bg-purple-500 rounded-full transition-all" style={{ width: `${signalPct}%` }} />
          </div>
          <p className="text-xs text-gray-400 mt-1">{signalPct.toFixed(0)}% signal quality</p>
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <Layers size={18} className="text-blue-600" />
          <h2 className="text-sm font-semibold text-gray-700">GATT Service Map</h2>
        </div>
        <div className="space-y-2">
          {gattServices.map(svc => (
            <div key={svc.uuid} className={`flex items-center justify-between p-3 rounded-lg text-xs ${svc.active ? 'bg-blue-50' : 'bg-gray-50'}`}>
              <div className="flex items-center gap-2">
                <Radio size={12} className={svc.active ? 'text-blue-600' : 'text-gray-400'} />
                <span className="font-medium">{svc.name}</span>
              </div>
              <code className="text-gray-400 hidden md:block">{svc.uuid}</code>
              {svc.active
                ? <CheckCircle2 size={12} className="text-green-500" />
                : <Clock size={12} className="text-gray-400" />}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <HelpCircle size={18} className="text-gray-500" />
          <h2 className="text-sm font-semibold text-gray-700">Troubleshooting Guide</h2>
        </div>
        <div className="space-y-3 text-sm text-gray-600">
          <div className="flex gap-2 items-start"><ShieldCheck size={14} className="text-green-500 mt-0.5 shrink-0" /><p><strong>Signal &lt; -80 dBm:</strong> Move the device closer. Obstructions reduce range.</p></div>
          <div className="flex gap-2 items-start"><ShieldCheck size={14} className="text-green-500 mt-0.5 shrink-0" /><p><strong>Disconnected:</strong> Power cycle the milk can device or press Reconnect above.</p></div>
          <div className="flex gap-2 items-start"><ShieldCheck size={14} className="text-green-500 mt-0.5 shrink-0" /><p><strong>Low battery:</strong> BLE power consumption increases. Ensure solar panel is unobstructed.</p></div>
        </div>
      </div>
    </div>
  )
}

