import React from 'react'
import { useNavigate } from 'react-router-dom'
import { Milk, Bluetooth, Clock, Thermometer, Sun } from 'lucide-react'
import { useApp } from '../context/AppContext'
import StatusBadge from '../components/StatusBadge'
import BatteryBar from '../components/BatteryBar'

export default function MyMilkCan() {
  const { currentCan, refreshFarmerData } = useApp()
  const nav = useNavigate()
  const t = currentCan?.latest

  const metrics = [
    { label: 'Temperature',   value: t ? `${t.temperature_c.toFixed(1)} °C` : '—',                      icon: Thermometer, to: '/temperature' },
    { label: 'Milk Quantity', value: t ? `${t.milk_quantity_litres.toFixed(1)} L` : '—',                 icon: Milk,        to: null },
    { label: 'Solar Voltage', value: t ? `${t.solar_voltage.toFixed(1)} V` : '—',                        icon: Sun,         to: '/battery-solar' },
    { label: 'Bluetooth',     value: t ? (t.bluetooth_connected ? 'Connected' : 'Disconnected') : '—',   icon: Bluetooth,   to: '/bluetooth' },
    { label: 'Battery Temp',  value: t ? `${(t.battery_temperature_c ?? 0).toFixed(1)} °C` : '—',        icon: Thermometer, to: '/battery-solar' },
    { label: 'Signal',        value: t ? `${t.signal_strength_dbm ?? '—'} dBm` : '—',                    icon: Clock,       to: '/bluetooth' },
  ]

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">{currentCan?.can_name ?? 'My Milk Can'}</h1>
            <p className="text-sm text-gray-500">{currentCan?.farmer_name}</p>
          </div>
          {currentCan && <StatusBadge status={currentCan.status} />}
        </div>
        {t && (
          <div className="space-y-2">
            <p className="text-xs text-gray-500">Battery Level</p>
            <BatteryBar voltage={t.battery_voltage} />
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {metrics.map(({ label, value, icon: Icon, to }) => (
          <div
            key={label}
            onClick={() => to && nav(to)}
            className={`bg-white rounded-xl p-4 shadow-sm border border-gray-100 ${to ? 'cursor-pointer hover:shadow-md' : ''}`}
          >
            <div className="flex items-center gap-2 mb-2 text-green-700">
              <Icon size={16} />
              <span className="text-xs text-gray-500">{label}</span>
            </div>
            <p className="font-bold text-gray-900">{value}</p>
          </div>
        ))}
      </div>

      <div className="flex gap-3">
        <button onClick={() => nav('/temperature')}   className="flex-1 py-2 bg-blue-50   text-blue-700   rounded-lg text-sm font-medium hover:bg-blue-100">📈 Temperature</button>
        <button onClick={() => nav('/battery-solar')} className="flex-1 py-2 bg-yellow-50 text-yellow-700 rounded-lg text-sm font-medium hover:bg-yellow-100">⚡ Battery</button>
        <button onClick={() => nav('/bluetooth')}     className="flex-1 py-2 bg-purple-50 text-purple-700 rounded-lg text-sm font-medium hover:bg-purple-100">📡 Bluetooth</button>
        <button onClick={refreshFarmerData}           className="flex-1 py-2 bg-green-50  text-green-700  rounded-lg text-sm font-medium hover:bg-green-100">🔄 Refresh</button>
      </div>
    </div>
  )
}

