import React from 'react'
import { Sun, BatteryCharging, Battery, Zap, Cpu, ShieldCheck, AlertTriangle, CheckCircle2, Sparkles } from 'lucide-react'
import { useApp } from '../context/AppContext'
import BatteryBar from '../components/BatteryBar'

export default function BatterySolar() {
  const { currentCan } = useApp()
  const t = currentCan?.latest

  const battPct  = t ? Math.min(100, Math.max(0, ((t.battery_voltage - 10.5) / (14.4 - 10.5)) * 100)) : 0
  const solarPct = t ? Math.min(100, Math.max(0, (t.solar_voltage / 22) * 100)) : 0
  const watt     = t ? (t.solar_voltage * 1.2).toFixed(1) : '—'
  const battStatus = !t ? 'offline' : t.battery_voltage > 12 ? 'good' : t.battery_voltage > 11 ? 'warning' : 'low'

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <BatteryCharging className="text-green-500" size={28} />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Battery & Solar Power</h1>
          <p className="text-gray-500 text-sm">Energy system for {currentCan?.can_name}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-3">
            <Battery className="text-green-500" size={20} />
            <h3 className="font-semibold text-gray-700">Battery</h3>
            {battStatus === 'good'    && <CheckCircle2 size={14} className="text-green-500" />}
            {battStatus === 'warning' && <AlertTriangle size={14} className="text-yellow-500" />}
            {battStatus === 'low'     && <AlertTriangle size={14} className="text-red-500" />}
          </div>
          <p className="text-3xl font-bold text-gray-900 mb-2">{t ? `${t.battery_voltage.toFixed(2)}V` : '—'}</p>
          {t && <BatteryBar voltage={t.battery_voltage} />}
          <p className="text-xs text-gray-400 mt-2">{battPct.toFixed(0)}% charge</p>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-3">
            <Sun className="text-yellow-500" size={20} />
            <h3 className="font-semibold text-gray-700">Solar Panel</h3>
          </div>
          <p className="text-3xl font-bold text-gray-900 mb-2">{t ? `${t.solar_voltage.toFixed(2)}V` : '—'}</p>
          <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-yellow-400 rounded-full transition-all" style={{ width: `${solarPct}%` }} />
          </div>
          <p className="text-xs text-gray-400 mt-2">Est. {watt}W output</p>
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <Zap size={18} className="text-yellow-500" />
          <h2 className="text-sm font-semibold text-gray-700">Energy Flow Diagram</h2>
        </div>
        <div className="flex items-center justify-center gap-4 py-4 flex-wrap">
          {[
            { label: 'Solar Panel',    sub: t ? `${t.solar_voltage.toFixed(1)}V`    : '—', Icon: Sun,         color: 'bg-yellow-100 text-yellow-700' },
            { label: '→',              sub: '', Icon: null, color: '' },
            { label: 'Battery',        sub: t ? `${t.battery_voltage.toFixed(1)}V`  : '—', Icon: Battery,     color: 'bg-green-100 text-green-700' },
            { label: '→',              sub: '', Icon: null, color: '' },
            { label: 'Peltier Cooler', sub: t ? `${t.temperature_c.toFixed(1)}°C`   : '—', Icon: Cpu,         color: 'bg-blue-100 text-blue-700' },
          ].map((item, i) =>
            item.Icon ? (
              <div key={i} className={`flex flex-col items-center p-3 rounded-xl ${item.color}`}>
                <item.Icon size={20} />
                <p className="text-xs font-semibold mt-1">{item.label}</p>
                <p className="text-xs">{item.sub}</p>
              </div>
            ) : (
              <span key={i} className="text-2xl text-gray-400 font-bold">{item.label}</span>
            )
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
        <div className="flex items-center gap-2 mb-4">
          <ShieldCheck size={18} className="text-green-600" />
          <h2 className="text-sm font-semibold text-gray-700">Voltage Reference</h2>
        </div>
        <div className="space-y-2">
          {[
            { label: '>12.6V',       color: 'bg-green-100 text-green-800',   icon: Sparkles,      desc: 'Fully charged' },
            { label: '12.0–12.6V',   color: 'bg-blue-100 text-blue-800',    icon: CheckCircle2,  desc: 'Good charge' },
            { label: '11.5–12.0V',   color: 'bg-yellow-100 text-yellow-800', icon: AlertTriangle, desc: 'Low — charge soon' },
            { label: '<11.5V',        color: 'bg-red-100 text-red-800',      icon: AlertTriangle, desc: 'Critical — may cut off' },
          ].map(({ label, color, icon: Icon, desc }) => (
            <div key={label} className={`flex items-center justify-between p-2.5 rounded-lg text-sm ${color}`}>
              <div className="flex items-center gap-2"><Icon size={14} /><span className="font-semibold">{label}</span></div>
              <span>{desc}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

