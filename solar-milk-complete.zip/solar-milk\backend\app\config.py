import os
from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="allow")

    PROJECT_NAME: str = "Solar Milk – Smart Dairy Monitoring API"
    VERSION: str = "1.0.0"
    API_V1_PREFIX: str = "/api"

    SECRET_KEY: str = os.getenv("SECRET_KEY", "solarmilk-secret-key-2026-supersecure-token-9686720081")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24

    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./solar_milk.db")

    BLE_ENABLED: bool = False
    BLE_SCAN_TIMEOUT: float = 10.0
    BLE_SERVICE_UUID: str = "19b10000-e8f2-537e-4f6c-d104768a1214"
    BLE_CHARACTERISTIC_UUID: str = "19b10001-e8f2-537e-4f6c-d104768a1214"
    BLE_CONTROL_UUID: str = "19b10002-e8f2-537e-4f6c-d104768a1214"

    SMS_MODE: str = os.getenv("SMS_MODE", "mock")
    SMS_COOLDOWN_MINUTES: int = int(os.getenv("SMS_COOLDOWN_MINUTES", "30"))
    TWILIO_ACCOUNT_SID: str = os.getenv("TWILIO_ACCOUNT_SID", "")
    TWILIO_AUTH_TOKEN: str = os.getenv("TWILIO_AUTH_TOKEN", "")
    TWILIO_FROM_NUMBER: str = os.getenv("TWILIO_FROM_NUMBER", "")
    FAST2SMS_API_KEY: str = os.getenv("FAST2SMS_API_KEY", "")
    FAST2SMS_SENDER_ID: str = os.getenv("FAST2SMS_SENDER_ID", "FSTSMS")
    FAST2SMS_MESSAGE_ROUTE: str = os.getenv("FAST2SMS_MESSAGE_ROUTE", "q")

    CORS_ORIGINS: List[str] = ["http://localhost:5173", "http://127.0.0.1:5173", "*"]

settings = Settings()

