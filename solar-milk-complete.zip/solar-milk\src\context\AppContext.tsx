import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react'
import { login as apiLogin } from '../api/authService'
import { getCanStatus, getCanHistory, ingestTelemetry } from '../api/sensorService'

export interface TelemetryPoint {
  id: number
  timestamp: string
  temperature_c: number
  battery_voltage: number
  solar_voltage: number
  milk_quantity_litres: number
  bluetooth_connected: boolean
  battery_temperature_c: number
  signal_strength_dbm: number
}

export interface CanStatus {
  can_id: string
  can_name: string
  farmer_name: string
  latest: TelemetryPoint | null
  status: 'normal' | 'warning' | 'critical' | 'offline'
  alerts_count: number
}

interface AppState {
  isAuthenticated: boolean
  token: string | null
  farmerId: string | null
  farmerName: string | null
  mobile: string | null
  currentCan: CanStatus | null
  history: TelemetryPoint[]
  isSimulating: boolean
  wsConnected: boolean
  login: (mobile: string, password: string) => Promise<void>
  logout: () => void
  refreshFarmerData: () => Promise<void>
  simulateScenario: (scenario: string) => Promise<void>
}

const AppContext = createContext<AppState | null>(null)

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}

function deriveCanId(farmerId: string): string {
  if (farmerId === 'f_chiranth') return 'can_chiranth_1'
  if (farmerId === 'f_anisha') return 'can_anisha_1'
  return farmerId
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(() => sessionStorage.getItem('sm_token'))
  const [farmerId, setFarmerId] = useState<string | null>(() => sessionStorage.getItem('sm_farmer_id'))
  const [farmerName, setFarmerName] = useState<string | null>(() => sessionStorage.getItem('sm_farmer_name'))
  const [mobile, setMobile] = useState<string | null>(() => sessionStorage.getItem('sm_mobile'))
  const [currentCan, setCurrentCan] = useState<CanStatus | null>(null)
  const [history, setHistory] = useState<TelemetryPoint[]>([])
  const [isSimulating, setIsSimulating] = useState(false)
  const [wsConnected, setWsConnected] = useState(false)
  const wsRef = useRef<WebSocket | null>(null)

  const isAuthenticated = !!token

  const refreshFarmerData = useCallback(async () => {
    if (!token || !farmerId) return
    try {
      const canId = deriveCanId(farmerId)
      const [status, hist] = await Promise.all([
        getCanStatus(token, canId),
        getCanHistory(token, canId, 50),
      ])
      setCurrentCan(status)
      setHistory(Array.isArray(hist) ? hist : [])
    } catch (err) {
      console.error('refreshFarmerData error:', err)
    }
  }, [token, farmerId])

  // WebSocket connection
  useEffect(() => {
    if (!token) return
    const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws'
    const ws = new WebSocket(`${protocol}://${window.location.host}/ws/telemetry?token=${token}`)
    wsRef.current = ws
    ws.onopen = () => setWsConnected(true)
    ws.onclose = () => setWsConnected(false)
    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data)
        if (msg.type === 'telemetry_update') {
          setCurrentCan((prev) => prev ? { ...prev, latest: msg.data, status: msg.status } : prev)
          setHistory((prev) => [msg.data, ...prev].slice(0, 100))
        }
      } catch {}
    }
    return () => ws.close()
  }, [token])

  // Poll every 30s when WS not available
  useEffect(() => {
    if (!isAuthenticated) return
    refreshFarmerData()
    const interval = setInterval(refreshFarmerData, 30000)
    return () => clearInterval(interval)
  }, [isAuthenticated, refreshFarmerData])

  const login = useCallback(async (mob: string, password: string) => {
    const resp = await apiLogin(mob, password)
    sessionStorage.setItem('sm_token', resp.access_token)
    sessionStorage.setItem('sm_farmer_id', resp.farmer_id)
    sessionStorage.setItem('sm_farmer_name', resp.farmer_name)
    sessionStorage.setItem('sm_mobile', resp.mobile)
    setToken(resp.access_token)
    setFarmerId(resp.farmer_id)
    setFarmerName(resp.farmer_name)
    setMobile(resp.mobile)
  }, [])

  const logout = useCallback(() => {
    sessionStorage.clear()
    setToken(null)
    setFarmerId(null)
    setFarmerName(null)
    setMobile(null)
    setCurrentCan(null)
    setHistory([])
    wsRef.current?.close()
  }, [])

  const simulateScenario = useCallback(async (scenario: string) => {
    if (!token || !farmerId) return
    setIsSimulating(true)
    const canId = deriveCanId(farmerId)
    const base = {
      can_id: canId,
      temperature_c: 4.2,
      battery_voltage: 12.4,
      solar_voltage: 18.1,
      milk_quantity_litres: 25.0,
      bluetooth_connected: true,
      battery_temperature_c: 32.0,
      signal_strength_dbm: -55,
    }
    const scenarios: Record<string, Partial<typeof base>> = {
      normal: {},
      warning_temp: { temperature_c: 8.5 },
      critical_temp: { temperature_c: 14.2 },
      low_battery: { battery_voltage: 10.8, solar_voltage: 5.2 },
      bluetooth_off: { bluetooth_connected: false, signal_strength_dbm: -100 },
    }
    try {
      await ingestTelemetry(token, { ...base, ...scenarios[scenario] })
      await refreshFarmerData()
    } finally {
      setIsSimulating(false)
    }
  }, [token, farmerId, refreshFarmerData])

  return (
    <AppContext.Provider value={{
      isAuthenticated, token, farmerId, farmerName, mobile,
      currentCan, history, isSimulating, wsConnected,
      login, logout, refreshFarmerData, simulateScenario,
    }}>
      {children}
    </AppContext.Provider>
  )
}
