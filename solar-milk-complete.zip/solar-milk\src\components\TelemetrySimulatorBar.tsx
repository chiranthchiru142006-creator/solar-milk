import React, { useState } from 'react'
import { useApp } from '../context/AppContext'
import {
  Activity, Snowflake, AlertTriangle, Flame,
  BatteryLow, Unplug, ChevronDown, ChevronUp,
} from 'lucide-react'

const SCENARIOS = [
  { key: 'normal',        label: 'Normal',        icon: Snowflake,     color: 'bg-green-100 text-green-700 hover:bg-green-200',  description: '4.2°C, 12.4V, BLE on' },
  { key: 'warning_temp',  label: 'Warn Temp',     icon: AlertTriangle, color: 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200', description: '8.5°C warning threshold' },
  { key: 'critical_temp', label: 'Critical Temp', icon: Flame,         color: 'bg-orange-100 text-orange-700 hover:bg-orange-200', description: '14.2°C — milk at risk' },
  { key: 'low_battery',   label: 'Low Battery',   icon: BatteryLow,    color: 'bg-red-100 text-red-700 hover:bg-red-200',         description: '10.8V, solar weak' },
  { key: 'bluetooth_off', label: 'BLE Disconnect',icon: Unplug,        color: 'bg-purple-100 text-purple-700 hover:bg-purple-200', description: 'Bluetooth disconnected' },
]

export const TelemetrySimulatorBar: React.FC = () => {
  const { currentCan, simulateScenario, isSimulating } = useApp()
  const [isOpen, setIsOpen] = useState(false)
  const [feedback, setFeedback] = useState<string | null>(null)

  const run = async (key: string) => {
    await simulateScenario(key)
    setFeedback(`✅ "${SCENARIOS.find(s => s.key === key)?.label}" scenario applied`)
    setTimeout(() => setFeedback(null), 3000)
  }

  if (!currentCan) return null

  return (
    <div className="bg-white border-b border-gray-200 shadow-sm">
      <button
        onClick={() => setIsOpen(o => !o)}
        className="w-full flex items-center justify-between px-6 py-2 text-xs font-semibold text-gray-500 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Activity size={14} className="text-green-600" />
          <span>Hardware Simulator</span>
          {isSimulating && <span className="text-green-600 animate-pulse">● Sending…</span>}
          {feedback && <span className="text-green-600">{feedback}</span>}
        </div>
        {isOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
      </button>
      {isOpen && (
        <div className="px-6 pb-3 flex flex-wrap gap-2">
          {SCENARIOS.map(({ key, label, icon: Icon, color, description }) => (
            <button
              key={key}
              disabled={isSimulating}
              onClick={() => run(key)}
              title={description}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all disabled:opacity-50 ${color}`}
            >
              <Icon size={13} />
              {label}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
