import React from 'react'

interface Props {
  status: 'normal' | 'warning' | 'critical' | 'offline'
  size?: 'sm' | 'md'
}

const CONFIG = {
  normal:   { label: 'Normal',   cls: 'bg-green-100 text-green-800 border-green-200' },
  warning:  { label: 'Warning',  cls: 'bg-yellow-100 text-yellow-800 border-yellow-200' },
  critical: { label: 'Critical', cls: 'bg-red-100 text-red-800 border-red-200' },
  offline:  { label: 'Offline',  cls: 'bg-gray-100 text-gray-600 border-gray-200' },
}

export default function StatusBadge({ status, size = 'md' }: Props) {
  const { label, cls } = CONFIG[status] ?? CONFIG.offline
  const sz = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-sm px-3 py-1'
  return (
    <span className={`inline-flex items-center rounded-full border font-medium ${sz} ${cls}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current mr-1.5 opacity-70" />
      {label}
    </span>
  )
}
