from sqlalchemy.orm import Session
from app.models.telemetry import TelemetryReading
from app.schemas.telemetry import TelemetryIngest

def ingest(db: Session, payload: TelemetryIngest) -> TelemetryReading:
    reading = TelemetryReading(
        can_id=payload.can_id,
        temperature_c=payload.temperature_c,
        battery_voltage=payload.battery_voltage,
        solar_voltage=payload.solar_voltage,
        milk_quantity_litres=payload.milk_quantity_litres,
        bluetooth_connected=payload.bluetooth_connected,
        battery_temperature_c=payload.battery_temperature_c or 30.0,
        signal_strength_dbm=payload.signal_strength_dbm or -60,
    )
    db.add(reading)
    db.commit()
    db.refresh(reading)
    return reading

def get_latest(db: Session, can_id: str):
    return (
        db.query(TelemetryReading)
        .filter(TelemetryReading.can_id == can_id)
        .order_by(TelemetryReading.timestamp.desc())
        .first()
    )

def get_history(db: Session, can_id: str, limit: int = 50):
    return (
        db.query(TelemetryReading)
        .filter(TelemetryReading.can_id == can_id)
        .order_by(TelemetryReading.timestamp.desc())
        .limit(limit)
        .all()
    )

def derive_status(latest) -> str:
    if not latest:
        return "offline"
    if latest.temperature_c > 12 or latest.battery_voltage < 11.0:
        return "critical"
    if latest.temperature_c > 8 or latest.battery_voltage < 11.5 or not latest.bluetooth_connected:
        return "warning"
    return "normal"
