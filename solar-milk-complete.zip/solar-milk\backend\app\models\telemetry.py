from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from app.database import Base

class TelemetryReading(Base):
    __tablename__ = "telemetry_readings"
    id                   = Column(Integer, primary_key=True, index=True, autoincrement=True)
    can_id               = Column(String, ForeignKey("milk_cans.id"), nullable=False, index=True)
    timestamp            = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    temperature_c        = Column(Float, nullable=False)
    battery_voltage      = Column(Float, nullable=False)
    solar_voltage        = Column(Float, nullable=False)
    milk_quantity_litres = Column(Float, default=0.0)
    bluetooth_connected  = Column(Boolean, default=True)
    battery_temperature_c = Column(Float, default=30.0)
    signal_strength_dbm  = Column(Integer, default=-60)
    milk_can             = relationship("MilkCan", back_populates="telemetry")

